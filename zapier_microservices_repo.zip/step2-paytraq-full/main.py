import os
import requests
import xml.etree.ElementTree as ET
from flask import Flask, request, jsonify

app = Flask(__name__)

PAYTRAQ_API_KEY = os.getenv("PAYTRAQ_API_KEY")
PAYTRAQ_API_TOKEN = os.getenv("PAYTRAQ_API_TOKEN")
PAYTRAQ_BASE = os.getenv("PAYTRAQ_BASE", "https://go.paytraq.com")

@app.get("/")
def health():
    return "OK", 200

@app.post("/run")
def run():
    body = request.get_json(silent=True) or {}
    document_id = body.get("document_id")
    if not document_id:
        return jsonify({"error": "Missing document_id"}), 400

    if not PAYTRAQ_API_KEY or not PAYTRAQ_API_TOKEN:
        return jsonify({"error": "Missing PAYTRAQ_API_KEY or PAYTRAQ_API_TOKEN"}), 500

    url = f"{PAYTRAQ_BASE}/api/sale/{document_id}?APIKey={PAYTRAQ_API_KEY}&APIToken={PAYTRAQ_API_TOKEN}"

    try:
        r = requests.get(url, timeout=30)
        r.raise_for_status()
        xml_text = r.text
        root = ET.fromstring(xml_text)
        doc_ref = root.findtext(".//Document/DocumentRef") or None
        return jsonify({"status": "ok", "document_id": str(document_id), "document_ref": doc_ref, "full_document": xml_text}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 502
