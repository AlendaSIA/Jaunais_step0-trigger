import os
import requests
import xml.etree.ElementTree as ET
from datetime import datetime
from flask import Flask, request, jsonify

app = Flask(__name__)

PAYTRAQ_API_KEY = os.getenv("PAYTRAQ_API_KEY")
PAYTRAQ_API_TOKEN = os.getenv("PAYTRAQ_API_TOKEN")
PAYTRAQ_BASE = os.getenv("PAYTRAQ_BASE", "https://go.paytraq.com")

@app.get("/")
def health():
    return "OK", 200

@app.post("/run")
def run():
    if not PAYTRAQ_API_KEY or not PAYTRAQ_API_TOKEN:
        return jsonify({"error": "Missing PAYTRAQ_API_KEY or PAYTRAQ_API_TOKEN"}), 500

    today = datetime.now().strftime("%Y-%m-%d")
    url = f"{PAYTRAQ_BASE}/api/sales?APIKey={PAYTRAQ_API_KEY}&APIToken={PAYTRAQ_API_TOKEN}&date_from={today}&date_till={today}&page=0"

    try:
        r = requests.get(url, timeout=30)
        r.raise_for_status()
        root = ET.fromstring(r.content)
        sales = root.findall(".//Sale")
        if not sales:
            return jsonify({"status": "ok", "found": 0, "message": "No documents today", "date": today}), 200

        last_doc = None
        for sale in sales:
            doc = sale.find(".//Document")
            if doc is None:
                continue
            doc_ref = doc.findtext("DocumentRef")
            doc_id = doc.findtext("DocumentID")
            if doc_id or doc_ref:
                last_doc = {"document_id": doc_id, "document_ref": doc_ref}

        if not last_doc:
            return jsonify({"error": "Could not find DocumentID/DocumentRef in response"}), 500

        return jsonify({"status": "ok", "date": today, **last_doc}), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 502
