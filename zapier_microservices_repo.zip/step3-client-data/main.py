import os
import requests
import xml.etree.ElementTree as ET
from flask import Flask, request, jsonify

app = Flask(__name__)

PAYTRAQ_API_KEY = os.getenv("PAYTRAQ_API_KEY")
PAYTRAQ_API_TOKEN = os.getenv("PAYTRAQ_API_TOKEN")
PAYTRAQ_BASE = os.getenv("PAYTRAQ_BASE", "https://go.paytraq.com")

@app.get("/")
def health():
    return "OK", 200

@app.post("/run")
def run():
    body = request.get_json(silent=True) or {}
    full_xml = body.get("full_document")
    if not full_xml:
        return jsonify({"error": "Missing full_document"}), 400

    if not PAYTRAQ_API_KEY or not PAYTRAQ_API_TOKEN:
        return jsonify({"error": "Missing PAYTRAQ_API_KEY or PAYTRAQ_API_TOKEN"}), 500

    try:
        root = ET.fromstring(full_xml)
        client = root.find(".//Document/Client")
        if client is None:
            return jsonify({"error": "Client not found in XML"}), 500

        client_id = client.findtext("ClientID")
        client_name = client.findtext("ClientName")
        if not client_id:
            return jsonify({"error": "ClientID missing in XML"}), 500

        url = f"{PAYTRAQ_BASE}/api/client/{client_id}"
        params = {"APIKey": PAYTRAQ_API_KEY, "APIToken": PAYTRAQ_API_TOKEN}
        r = requests.get(url, params=params, timeout=30)
        r.raise_for_status()
        croot = ET.fromstring(r.text)

        email = (croot.findtext("Email") or "").strip() or None
        phone = (croot.findtext("Phone") or "").strip() or None
        reg = (croot.findtext("RegNumber") or "").strip() or None

        return jsonify({
            "status": "ok",
            "client_id": str(client_id),
            "client_name": client_name,
            "contact_email": email,
            "contact_phone": phone,
            "reg_number": reg
        }), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 502
