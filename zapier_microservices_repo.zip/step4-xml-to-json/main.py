import xmltodict
from flask import Flask, request, jsonify

app = Flask(__name__)

@app.get("/")
def health():
    return "OK", 200

@app.post("/run")
def run():
    body = request.get_json(silent=True) or {}
    xml_str = body.get("full_document")
    if not xml_str:
        return jsonify({"error": "Missing full_document"}), 400
    try:
        data = xmltodict.parse(xml_str)
        return jsonify({"status": "ok", "json": data}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500
