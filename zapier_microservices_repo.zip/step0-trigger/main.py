import os
import requests
from flask import Flask, request, jsonify

app = Flask(__name__)

STEP1_URL = os.getenv("STEP1_URL")  # e.g. https://step1-paytraq-last-xxx.run.app/run
STEP2_URL = os.getenv("STEP2_URL")  # e.g. https://step2-paytraq-full-xxx.run.app/run
STEP3_URL = os.getenv("STEP3_URL")  # e.g. https://step3-client-data-xxx.run.app/run
STEP4_URL = os.getenv("STEP4_URL")  # e.g. https://step4-xml-to-json-xxx.run.app/run

@app.get("/")
def healthcheck():
    return "OK", 200

def post_json(url, payload):
    r = requests.post(url, json=payload, timeout=60)
    return r.status_code, r.json()

@app.post("/run")
def run():
    # run full chain (if URLs are set), otherwise just confirms trigger works
    if not STEP1_URL:
        return jsonify({"status":"ok","message":"STEP1_URL not set; trigger only"}), 200

    out = {"status": "ok"}

    s1_code, s1 = post_json(STEP1_URL, {})
    out["step1_status_code"] = s1_code
    out["step1"] = s1
    if "document_id" not in s1:
        return jsonify(out), 200

    if STEP2_URL:
        s2_code, s2 = post_json(STEP2_URL, {"document_id": s1["document_id"]})
        out["step2_status_code"] = s2_code
        out["step2"] = s2
    else:
        return jsonify(out), 200

    if STEP3_URL and isinstance(out.get("step2"), dict) and out["step2"].get("full_document"):
        s3_code, s3 = post_json(STEP3_URL, {"full_document": out["step2"]["full_document"]})
        out["step3_status_code"] = s3_code
        out["step3"] = s3

    if STEP4_URL and isinstance(out.get("step2"), dict) and out["step2"].get("full_document"):
        s4_code, s4 = post_json(STEP4_URL, {"full_document": out["step2"]["full_document"]})
        out["step4_status_code"] = s4_code
        out["step4"] = s4

    return jsonify(out), 200

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
