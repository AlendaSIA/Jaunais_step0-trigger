# Zapier replacement (microservices)

## Services
- step0-trigger: POST /run calls step1->step2->step3->step4 (if STEP*_URL env vars are set)
- step1-paytraq-last: POST /run returns last document_id/document_ref for today
- step2-paytraq-full: POST /run with {"document_id": "..."} returns full_document XML
- step3-client-data: POST /run with {"full_document":"<xml>"} returns client email/phone/regnr
- step4-xml-to-json: POST /run with {"full_document":"<xml>"} returns parsed JSON

## Local test (optional)
Each folder is a separate Cloud Run service.

## Quick curl tests (CMD)
Step1:
curl -X POST https://STEP1_URL/run -H "Content-Type: application/json" -d "{}"

Step2:
curl -X POST https://STEP2_URL/run -H "Content-Type: application/json" -d "{\"document_id\":\"123\"}"

Step0 full chain:
curl -X POST https://STEP0_URL/run -H "Content-Type: application/json" -d "{}"
